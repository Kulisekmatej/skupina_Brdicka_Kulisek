﻿// Dedicnost4_1sk.cpp : Tento soubor obsahuje funkci main. Provádění programu se tam zahajuje a ukončuje.
//

#include <iostream>
#include <algorithm>
#include "Dog.h"

//5 % 2 = 1  // 2 * 2 + 1
//7 % 5 = 2  // 5 * 1 + 2
//13 % 5 = 3 // 5 * 2 + 3
void writeOdd100()
{
	for (int i = 1; i <= 100; ++i)  // i += 2
    {
        //bud liche anebo delitelne 3
        if (i % 2 == 1 || i % 3 == 0)
            printf("%d ", i);
    }
}

// na sudych indexech anebo prvky jsou delitelne trema
void writeArrayCondition(int arr[], int size)
{
    for (int i = 0; i < size; ++i)
    {
        if (i % 2 == 0 || arr[i] % 3 == 0)
            printf("%d ", arr[i]);
    }
}

int main()
{
	////vytvoreni instance tridy Animal
	//Animal animal("Generic Animal", 5, 20);
	//std::cout << "Jmeno: " << animal.getName() << ", Vek: " << animal.getAge() << '\n';
	//animal.speak();

	////dynamicka alokace pameti pro objekt tridy Animal
	//Animal* animal1 = new Animal("Generic Animal", 5, 20);
 //   animal1->speak();
	//delete animal1;

    Dog rex("Rex", 4, "Labrador");
    std::cout << "Jmeno: " << rex.getName() << ", Vek: " << rex.getAge() << ", Plemeno: " << rex.getBreed() << '\n';
    rex.speak();
    rex.speakParent();

    rex.wagTail();

    //Polymorfismus přes ukazatel na základní třídu
    Animal* a = &rex;
    a->speak();

    return 0;
}

// Spuštění programu: Ctrl+F5 nebo nabídka Ladit > Spustit bez ladění
// Ladění programu: F5 nebo nabídka Ladit > Spustit ladění

// Tipy pro zahájení práce:
//   1. K přidání nebo správě souborů použijte okno Průzkumník řešení.
//   2. Pro připojení ke správě zdrojového kódu použijte okno Team Explorer.
//   3. K zobrazení výstupu sestavení a dalších zpráv použijte okno Výstup.
//   4. K zobrazení chyb použijte okno Seznam chyb.
//   5. Pokud chcete vytvořit nové soubory kódu, přejděte na Projekt > Přidat novou položku. Pokud chcete přidat do projektu existující soubory kódu, přejděte na Projekt > Přidat existující položku.
//   6. Pokud budete chtít v budoucnu znovu otevřít tento projekt, přejděte na Soubor > Otevřít > Projekt a vyberte příslušný soubor .sln.
