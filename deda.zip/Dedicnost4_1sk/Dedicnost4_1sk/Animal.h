#pragma once

#include <string>

class Animal {
public:
	// Konstruktor zakladn� t��dy, ma stejny nazev jako trida
    Animal(const std::string& name,
        int age,
        int weight);
	// Virtualni destruktor pro spravne uvolneni pameti pri dedeni
	// destruktor ma stejny nazev jako trida, ale s tildou (~) pred ni
    virtual ~Animal();

    //dalsi metody
    const std::string& getName() const;
    int getAge() const;

    // Virtu�ln� metoda, aby odvozen� t��dy mohly p�epsat chov�n�
    virtual void speak() const;

protected:
    std::string mName;
    int mAge;
	int mWeight;
};